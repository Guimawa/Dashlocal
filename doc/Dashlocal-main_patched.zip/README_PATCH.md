
# Patch: Handshake Orbit Dashboard integrated

This patch adds a deterministic "Orbit" bubble UI and two API routes for project folders & snapshots.
You can access the new UI at `/handshake` when running your Next.js app.

## Files added
- `app/handshake/page.tsx` (UI only, no API handlers)
- `app/api/projects/create/route.ts` (POST create project: creates folder + metadata + snapshots/)
- `app/api/projects/save/route.ts` (POST save snapshot JSON inside snapshots/)
- `lib/fs-projects.ts` (filesystem helpers)
- `__tests__/fs-projects.test.ts`, `vitest.config.ts` (optional tests)

## Install deps
```bash
npm i react-force-graph-2d lucide-react
```

## (Optional) choose workspace dir for FS writes
- macOS/Linux: `export WORKSPACE_DIR="$PWD/workspace"`
- Windows PowerShell: `$env:WORKSPACE_DIR="$PWD\workspace"`

## Run
```bash
npm run dev
# open /handshake
```

## Important
- Do not declare `export async function POST(...)` in any UI file. API handlers must live under `app/api/.../route.ts`.
- Platforms with read-only FS won't support these endpoints; use locally or self-hosted.
