import './globals.css'
import React from 'react'
export const metadata = { title: 'Jarvis Expert Ultra', description: 'Orbit Dashboard' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  )
}
