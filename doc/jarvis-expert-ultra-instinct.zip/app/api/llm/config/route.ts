export async function GET() {
  const cfg = {
    backend: process.env.LLM_BACKEND || 'groq',
    groq_model: process.env.GROQ_MODEL || 'llama3-8b-8192',
    ollama_host: process.env.OLLAMA_HOST || 'http://127.0.0.1:11434',
    ollama_model: process.env.OLLAMA_MODEL || 'llama3'
  };
  return new Response(JSON.stringify(cfg), { status: 200, headers: { 'Content-Type': 'application/json' } });
}
