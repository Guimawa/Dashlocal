export const runtime = 'nodejs';

const SYS_PROMPT = 'You are Jarvis EXPERT ULTRA INSTINCT: a crisp, practical mentor. Answer briefly with concrete steps.';

async function callGroq(prompt: string) {
  const model = process.env.GROQ_MODEL || 'llama3-8b-8192';
  const apiKey = process.env.GROQ_API_KEY || '';
  if (!apiKey) return { ok: false, status: 400, error: 'Missing GROQ_API_KEY' };
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages: [
      { role: 'system', content: SYS_PROMPT },
      { role: 'user', content: prompt }
    ]})
  });
  if (!res.ok) return { ok: false, status: res.status, error: await res.text() };
  const j = await res.json();
  const text = j.choices?.[0]?.message?.content ?? '';
  return { ok: true, status: 200, text };
}

async function callOllama(prompt: string) {
  const host = process.env.OLLAMA_HOST || 'http://127.0.0.1:11434';
  const model = process.env.OLLAMA_MODEL || 'llama3';
  const res = await fetch(`${host}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, stream: false, messages: [
      { role: 'system', content: SYS_PROMPT },
      { role: 'user', content: prompt }
    ]})
  });
  if (!res.ok) return { ok: false, status: res.status, error: await res.text() };
  const j = await res.json();
  const text = j.message?.content ?? '';
  return { ok: true, status: 200, text };
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const prompt = body?.prompt || '';
    const backend = (process.env.LLM_BACKEND || 'groq').toLowerCase();
    const out = backend === 'ollama' ? await callOllama(prompt) : await callGroq(prompt);
    if (!out.ok) {
      return new Response(JSON.stringify({ error: out.error }), { status: out.status, headers: { 'Content-Type': 'application/json' } });
    }
    return new Response(JSON.stringify({ text: out.text }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err?.message || 'unexpected error' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}
