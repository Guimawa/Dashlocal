export const runtime = 'nodejs';
import { createProjectDir } from '@/lib/fs-projects';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const name = body?.name;
    const result = await createProjectDir(name);
    if (!result.ok) {
      return new Response(JSON.stringify({ error: result.error }), { status: result.status, headers: { 'Content-Type': 'application/json' } });
    }
    return new Response(JSON.stringify(result.data), { status: result.status, headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ error: 'unexpected error' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}
