import { describe, it, expect } from 'vitest';
import { promises as fs } from 'fs';
import os from 'os';
import path from 'path';
import { createProjectDir, saveSnapshot, toSlug } from '@/lib/fs-projects';

async function makeTmpDir() {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ultra-fs-'));
  return root;
}

describe('fs-projects', () => {
  it('toSlug is stable', () => {
    expect(toSlug('Mon Projet Démo!!')).toBe('mon-projet-demo');
  });
  it('creates a project directory with metadata and snapshots folder', async () => {
    const root = await makeTmpDir();
    const res = await createProjectDir('Mon Projet Test', root);
    expect(res.ok).toBe(true);
    if (!res.ok) return;
    const metaPath = path.join(root, res.data.slug, 'metadata.json');
    const snapsDir = path.join(root, res.data.slug, 'snapshots');
    const meta = JSON.parse(await fs.readFile(metaPath, 'utf-8'));
    const snapsStat = await fs.stat(snapsDir);
    expect(meta.name).toBe('Mon Projet Test');
    expect(snapsStat.isDirectory()).toBe(true);
  });
  it('saves a snapshot json file', async () => {
    const root = await makeTmpDir();
    const res = await createProjectDir('Snap Demo', root);
    if (!res.ok) throw new Error('create failed');
    const save = await saveSnapshot(res.data.slug, { hello: 'world' }, root);
    expect(save.ok).toBe(true);
    if (!save.ok) return;
    const fileStat = await fs.stat(save.data.file);
    expect(fileStat.isFile()).toBe(true);
    const parsed = JSON.parse(await fs.readFile(save.data.file, 'utf-8'));
    expect(parsed.hello).toBe('world');
  });
});
