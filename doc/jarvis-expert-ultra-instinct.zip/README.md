# Jarvis — EXPERT ULTRA INSTINCT (Orbit Dashboard)

Cockpit de gestion de projets avec bulles expansives (projets > détails > sous-détails), actions concrètes (création de dossiers, snapshots), import/export, et un Mentor IA (GROQ cloud ou OLLAMA local).

## Lancer
```bash
npm i
npm run dev
# http://localhost:3000/handshake
```

> Pour écrire sur disque (création de projets/snapshots), définissez WORKSPACE_DIR dans `.env` :
```bash
cp .env.example .env
# macOS/Linux
export WORKSPACE_DIR="$PWD/workspace"
# Windows PowerShell
# $env:WORKSPACE_DIR="$PWD\workspace"
```

## LLM (Mentor)
- `.env`: `LLM_BACKEND=groq` (avec `GROQ_API_KEY`) ou `LLM_BACKEND=ollama` (avec `OLLAMA_HOST` + `OLLAMA_MODEL`).
- UI: bouton **Mentor** en haut à droite.

## Fonctions clés
- Bulles **Orbit** déterministes, expansion **animée**, re-layout quand on ouvre/ferme.

- **Créer un projet** → `app/api/projects/create` (dossier + metadata + snapshots/)

- **Snapshot** d’un sous-graphe → `app/api/projects/save`

- **Export**: JSON / CSV (nodes) / PNG (canvas)

- **Import**: JSON ({nodes,links})

- Filtres: **Score**, **Recherche**

- Toggle **Orbit/Force**

## Tests
```bash
npm i -D vitest
npm run test
```

## Important
- Les handlers API restent dans `app/api/.../route.ts`.

- En hébergement lecture seule, la création de dossiers/snapshots ne fonctionnera pas (utilisez local/self-hosted).
