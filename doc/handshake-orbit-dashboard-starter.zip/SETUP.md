# Handshake Orbit Dashboard — Starter Drop-in

## Files you just downloaded
- `app/handshake/page.tsx` – UI only (no API handlers)
- `app/api/projects/create/route.ts` – POST create project (creates folder + metadata + snapshots/)
- `app/api/projects/save/route.ts` – POST save snapshot (writes JSON inside snapshots/)
- `lib/fs-projects.ts` – pure FS helpers (used by the API routes)
- `__tests__/fs-projects.test.ts`, `vitest.config.ts` – basic tests

## How to use in your Next.js app
1. Copy the `app/` and `lib/` folders into the root of your Next.js project (merge if they already exist).
2. Install deps: `npm i react-force-graph-2d lucide-react`
3. (Optional) choose workspace dir for snapshots:
   - macOS/Linux: `export WORKSPACE_DIR="$PWD/workspace"`
   - Windows PowerShell: `$env:WORKSPACE_DIR="$PWD\workspace"`
4. Run: `npm run dev` and open `/handshake`

## Run tests (optional)
```bash
npm i -D vitest
npx vitest run
```

## Notes
- Keep API handlers *only* inside `app/api/.../route.ts`. Do not put `POST` in UI files.
- If deploying to a platform with read-only FS, the FS endpoints will only work locally/self-hosted.
