// lib/fs-projects.ts
import { promises as fs } from 'fs';
import path from 'path';

export function toSlug(name: string): string {
  return (name || 'project')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');
}

function getRootDir(custom?: string) {
  const root = custom || process.env.WORKSPACE_DIR || path.join(process.cwd(), 'workspace');
  return root;
}

export async function createProjectDir(name: string, rootDir?: string) {
  if (!name || !name.trim()) {
    return { ok: false as const, status: 400 as const, error: 'name is required' };
  }
  const slug = toSlug(name.trim());
  const ROOT = getRootDir(rootDir);
  const dir = path.join(ROOT, slug);
  await fs.mkdir(dir, { recursive: true });
  await fs.mkdir(path.join(dir, 'snapshots'), { recursive: true });
  const meta = { name: name.trim(), slug, createdAt: new Date().toISOString() };
  await fs.writeFile(path.join(dir, 'metadata.json'), JSON.stringify(meta, null, 2), 'utf-8');
  return { ok: true as const, status: 201 as const, data: { slug, path: dir, id: slug } };
}

export async function saveSnapshot(slug: string, snapshot: any, rootDir?: string) {
  if (!slug || !slug.trim()) {
    return { ok: false as const, status: 400 as const, error: 'slug (id) is required' };
  }
  const ROOT = getRootDir(rootDir);
  const dir = path.join(ROOT, slug, 'snapshots');
  await fs.mkdir(dir, { recursive: true });
  const file = path.join(dir, `${Date.now()}.json`);
  await fs.writeFile(file, JSON.stringify(snapshot ?? {}, null, 2), 'utf-8');
  return { ok: true as const, status: 200 as const, data: { file } };
}
