// app/api/projects/save/route.ts
import { saveSnapshot } from '@/lib/fs-projects';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const slug = body?.slug || body?.id;
    const snapshot = body?.snapshot;
    const result = await saveSnapshot(String(slug || ''), snapshot);
    if (!result.ok) {
      return new Response(JSON.stringify({ error: result.error }), { status: result.status, headers: { 'Content-Type': 'application/json' } });
    }
    return new Response(JSON.stringify(result.data), { status: result.status, headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    return new Response(JSON.stringify({ error: 'unexpected error' }), { status: 500, headers: { 'Content-Type': 'application/json' } });
  }
}
